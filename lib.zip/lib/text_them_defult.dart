import 'package:color_theam_fonts/defult_text.dart';
import 'package:flutter/material.dart';



class TTextTheme {
  static TextTheme lightTextTheme() {
    return TextTheme(
      displayLarge: TTextThemeDefaults.lightDisplayLarge,
      displayMedium: TTextThemeDefaults.lightDisplayMedium,
      displaySmall: TTextThemeDefaults.lightDisplaySmall,
      headlineLarge: TTextThemeDefaults.lightHeadlineLarge,
      headlineMedium: TTextThemeDefaults.lightHeadlineMedium,
      headlineSmall: TTextThemeDefaults.lightHeadlineSmall, // New
      titleLarge: TTextThemeDefaults.lightTitleLarge, // New
      titleMedium: TTextThemeDefaults.lightTitleMedium, // New
      titleSmall: TTextThemeDefaults.lightTitleSmall,
      bodyLarge: TTextThemeDefaults.lightBodyLarge, // New
      bodyMedium: TTextThemeDefaults.lightBodyMedium, // New
      bodySmall: TTextThemeDefaults.lightBodySmall, // New
      labelLarge: TTextThemeDefaults.lightLabelLarge, // New
      labelMedium: TTextThemeDefaults.lightLabelMedium, // New
      labelSmall: TTextThemeDefaults.lightLabelSmall, // New
    );
  }

  static TextTheme darkTextTheme() {
    return TextTheme(
      displayLarge: TTextThemeDefaults.darkDisplayLarge,
      displayMedium: TTextThemeDefaults.darkDisplayMedium,
      displaySmall: TTextThemeDefaults.darkDisplaySmall,
      headlineLarge: TTextThemeDefaults.darkHeadlineLarge,
      headlineMedium: TTextThemeDefaults.darkHeadlineMedium,
      headlineSmall: TTextThemeDefaults.darkHeadlineSmall, // New
      titleLarge: TTextThemeDefaults.darkTitleLarge, // New
      titleMedium: TTextThemeDefaults.darkTitleMedium, // New
      titleSmall: TTextThemeDefaults.darkTitleSmall,
      bodyLarge: TTextThemeDefaults.darkBodyLarge, // New
      bodyMedium: TTextThemeDefaults.darkBodyMedium, // New
      bodySmall: TTextThemeDefaults.darkBodySmall, // New
      labelLarge: TTextThemeDefaults.darkLabelLarge, // New
      labelMedium: TTextThemeDefaults.darkLabelMedium, // New
      labelSmall: TTextThemeDefaults.darkLabelSmall, // New
    );
  }
}
